package com.bottomline.paymentservices.bottomlinepaymentservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bottomline.paymentservices.bottomlinepaymentservice.payment.PaymentDetail;

public interface PaymentServiceRepository extends JpaRepository<PaymentDetail, Integer> {

}
