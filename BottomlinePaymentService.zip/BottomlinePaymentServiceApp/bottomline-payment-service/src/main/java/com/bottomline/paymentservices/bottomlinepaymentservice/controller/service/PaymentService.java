package com.bottomline.paymentservices.bottomlinepaymentservice.controller.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bottomline.paymentservices.bottomlinepaymentservice.dao.PaymentServiceRepository;
import com.bottomline.paymentservices.bottomlinepaymentservice.payment.PaymentDetail;
import com.bottomline.paymentservices.bottomlinepaymentservice.payment.WithoutLastPaymentDetail;

/*
 * This is service class which is processing the request coming from controller
 * */

@Service
public class PaymentService {

	@Autowired
	private PaymentServiceRepository paymentServiceRepo;

	public void createPaymentPlan(PaymentDetail paymentDetail) {
		paymentServiceRepo.save(paymentDetail);
	}

	public Object getPaymentPlanById(Integer id) {
		List<PaymentDetail> pdlist = paymentServiceRepo.findAll();
		for (PaymentDetail pd : pdlist) {
			if (pd.getPaymentId() == id) {
				if (pd.getLastAmount() == pd.getRegularPaymentAmount()) {
					WithoutLastPaymentDetail pd1 = new WithoutLastPaymentDetail();
					pd1.setPaymentId(id);
					pd1.setNumberOfPayments(pd.getNumberOfPayments());
					pd1.setRegularPaymentAmount(pd.getRegularPaymentAmount());
					pd1.setTotalAmount(pd.getTotalAmount());
					return pd1;
				}
				return pd;
			}
		}
		return null;
	}

	public List<PaymentDetail> getAllPaymentPlan() {
		return paymentServiceRepo.findAll();
	}
}
