package com.bottomline.paymentservices.bottomlinepaymentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BottomlinePaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
