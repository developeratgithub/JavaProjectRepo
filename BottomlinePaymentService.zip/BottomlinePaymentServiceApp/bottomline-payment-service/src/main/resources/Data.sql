insert into payment_detail values(1, '2.4', 4, '2.5','10.00');
insert into payment_detail values(2, '24', 4, '25.00','100.00');
insert into payment_detail values(3, '245', 4, '250.00','1000.00');
insert into payment_detail values(4, '2500', 4, '2500','10000.00');