package com.bottomline.paymentservices.bottomlinepaymentservice.payment;

//Simple Bean
public class WithoutLastPaymentDetail {

	private Integer paymentId;
	private double totalAmount;
	private Integer numberOfPayments;
	private double regularPaymentAmount;

	public Integer getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Integer getNumberOfPayments() {
		return numberOfPayments;
	}

	public void setNumberOfPayments(Integer numberOfPayments) {
		this.numberOfPayments = numberOfPayments;
	}

	public double getRegularPaymentAmount() {
		return regularPaymentAmount;
	}

	public void setRegularPaymentAmount(double regularPaymentAmount) {
		this.regularPaymentAmount = regularPaymentAmount;
	}

	public WithoutLastPaymentDetail() {
		super();
	}

	public WithoutLastPaymentDetail(Integer paymentId, double totalAmount, Integer numberOfPayments,
			double regularPaymentAmount) {
		super();
		this.paymentId = paymentId;
		this.totalAmount = totalAmount;
		this.numberOfPayments = numberOfPayments;
		this.regularPaymentAmount = regularPaymentAmount;
	}
}
