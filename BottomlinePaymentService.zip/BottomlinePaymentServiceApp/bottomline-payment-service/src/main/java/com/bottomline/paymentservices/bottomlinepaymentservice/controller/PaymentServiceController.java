package com.bottomline.paymentservices.bottomlinepaymentservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bottomline.paymentservices.bottomlinepaymentservice.controller.service.PaymentService;
import com.bottomline.paymentservices.bottomlinepaymentservice.payment.PaymentDetail;

@RestController
public class PaymentServiceController {
	
	@Autowired
	private PaymentService paymentService;

	//Method to create the new payment plan
	@PostMapping("/payment")
	public void createPaymentPlan(@RequestBody PaymentDetail paymentDetail) {
		paymentService.createPaymentPlan(paymentDetail);
	}
	
	//Method to get the specific payment plan
	@GetMapping("/payment/{id}")
	public Object getPaymentPlan(@PathVariable int id) {	
		return paymentService.getPaymentPlanById(id);
	}
	
	//Method to get all the plan
	@GetMapping("/payment")
	public List<PaymentDetail> getAllPaymentPlan() {	
		return paymentService.getAllPaymentPlan();
	}
}
