package com.bottomline.paymentservices.bottomlinepaymentservice.payment;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


//Persistence class
@Entity
public class PaymentDetail implements Serializable {

	private static final long serialVersionUID = 4901321426772703040L;

	@Id
	@GeneratedValue
	private Integer paymentId;

	private double totalAmount;

	private Integer numberOfPayments;

	private double regularPaymentAmount;

	private double lastAmount;

	public Integer getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Integer getNumberOfPayments() {
		return numberOfPayments;
	}

	public void setNumberOfPayments(Integer numberOfPayments) {
		this.numberOfPayments = numberOfPayments;
	}

	public double getRegularPaymentAmount() {
		return regularPaymentAmount;
	}

	public void setRegularPaymentAmount(double regularPaymentAmount) {
		this.regularPaymentAmount = regularPaymentAmount;
	}

	public double getLastAmount() {
		return lastAmount;
	}

	public void setLastAmount(double lastAmount) {
		this.lastAmount = lastAmount;
	}

	public PaymentDetail() {

	}

	public PaymentDetail(Integer paymentId, double totalAmount, Integer numberOfPayments, double regularPaymentAmount,
			double lastAmount) {
		super();
		this.paymentId = paymentId;
		this.totalAmount = totalAmount;
		this.numberOfPayments = numberOfPayments;
		this.regularPaymentAmount = regularPaymentAmount;
		this.lastAmount = lastAmount;
	}

}
